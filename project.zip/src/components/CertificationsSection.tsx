import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { GraduationCap } from "lucide-react";

interface Certification {
  title: string;
  description: string;
  icon: React.ElementType;
}

const certifications: Certification[] = [
  {
    title: "Oracle Generative AI Certification",
    description: "Completed Oracle's Generative AI certification, gaining practical expertise in large language models, prompt engineering, and AI integration.",
    icon: GraduationCap,
  },
  {
    title: "Coursera Machine Learning Specialization",
    description: "Supervised ML, Advanced Learning Algorithms, Unsupervised Learning, Recommenders, and Reinforcement Learning.",
    icon: GraduationCap,
  },
];

export const CertificationsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="certifications" ref={ref} className="min-h-screen flex items-center py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, ease: "easeOut" }}
          className="max-w-6xl mx-auto"
        >
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2, duration: 1.0, ease: [0.22, 1, 0.36, 1] }}
            className="font-heading text-5xl md:text-6xl mb-16 text-center ink-text"
          >
            Certifications
          </motion.h2>

          {/* Certifications Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {certifications.map((cert, index) => {
              const IconComponent = cert.icon;
              return (
                <motion.div
                  key={cert.title}
                  initial={{ opacity: 0, y: 40 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ 
                    delay: 0.3 + index * 0.15, 
                    duration: 0.8, 
                    ease: [0.22, 1, 0.36, 1]
                  }}
                  className="relative group"
                  whileHover={{ 
                    scale: 1.03,
                    transition: { duration: 0.3, ease: "easeInOut" }
                  }}
                >
                  <div
                    className="bg-card/90 backdrop-blur-sm p-6 rounded-xl shadow-[var(--shadow-paper)] hover:shadow-[0_4px_20px_rgba(0,0,0,0.15)] transition-all duration-300 ease-in-out border border-border/20 hover:border-accent/30 relative overflow-hidden"
                    style={{
                      borderRadius: '12px',
                    }}
                  >
                    {/* Icon at top left */}
                    <div className="flex items-start gap-4 mb-4">
                      <div className="relative w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center group-hover:bg-accent/30 transition-colors duration-300">
                        <IconComponent 
                          className="w-6 h-6 text-accent transition-transform duration-300 group-hover:scale-110" 
                        />
                      </div>
                      
                      <div className="flex-1">
                        <h3 className="font-heading text-xl md:text-2xl mb-2 text-foreground group-hover:text-accent transition-colors duration-300">
                          {cert.title}
                        </h3>
                      </div>
                    </div>
                    
                    {/* Description */}
                    <p className="font-body text-base leading-relaxed text-muted-foreground">
                      {cert.description}
                    </p>

                    {/* Decorative corner */}
                    <div className="absolute top-2 right-2 w-8 h-8 border-t-2 border-r-2 border-accent/10 rounded-tr-lg opacity-50 group-hover:opacity-100 group-hover:border-accent/30 transition-all duration-300" />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

