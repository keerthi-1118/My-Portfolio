import { motion, useScroll, useTransform } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import quillInk from "@/assets/quill-ink.jpg";
import contentBg from "@/assets/Content.png";
import { Button } from "./ui/button";
import { FileText } from "lucide-react";

export const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false, margin: "-100px" });

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0.8, 1, 1, 0.95]);

  return (
    <section id="about" ref={ref} className="min-h-screen flex items-center py-20 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <motion.div
          style={{ opacity, scale }}
          initial={{ opacity: 0, y: -100 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: -100 }}
          exit={{ opacity: 0, y: -100, scale: 0.8 }}
          transition={{ duration: 1.2, ease: [0.6, 0.05, 0.01, 0.9] }}
          className="max-w-6xl mx-auto"
        >
          <h2 className="font-heading text-5xl md:text-6xl mb-12 text-center ink-text">
            The Writer
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Portrait - Circular */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.4, duration: 1, ease: "easeOut" }}
              className="relative group mx-auto w-72 h-72"
            >
              <motion.div
                className="w-full h-full rounded-full overflow-hidden shadow-[0_10px_30px_rgba(138,90,68,0.3)] border-4 border-accent/20 relative"
                whileHover={{
                  scale: 1.1,
                  rotate: 5,
                }}
                transition={{
                  type: "spring",
                  stiffness: 200,
                  damping: 15,
                  duration: 0.6
                }}
                style={{
                  boxShadow: "0 10px 30px rgba(138, 90, 68, 0.3)"
                }}
              >
                <motion.div
                  whileHover={{
                    boxShadow: "0 20px 60px rgba(138, 90, 68, 0.5), 0 0 50px rgba(212, 175, 55, 0.4)"
                  }}
                  transition={{ duration: 0.4 }}
                  className="w-full h-full"
                >
                  <img
                    src={quillInk}
                    alt="Keerthi Tadikonda - Full Stack Developer"
                    className="w-full h-full object-cover opacity-80 sepia transition-all duration-500 group-hover:opacity-95 group-hover:scale-110"
                  />
                </motion.div>
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
              </motion.div>
              {/* Decorative rings */}
              <motion.div
                className="absolute -top-4 -right-4 w-20 h-20 border-4 border-accent rounded-full opacity-50"
                whileHover={{ scale: 1.15, rotate: 90 }}
                transition={{ type: "spring", stiffness: 300 }}
              />
              <motion.div
                className="absolute -bottom-4 -left-4 w-16 h-16 border-4 border-secondary rounded-full opacity-40"
                whileHover={{ scale: 1.15, rotate: -90 }}
                transition={{ type: "spring", stiffness: 300 }}
              />
            </motion.div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, y: -80 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.6, duration: 1.2, ease: [0.6, 0.05, 0.01, 0.9] }}
              className="space-y-6"
            >
              <div className="relative w-full flex justify-center items-center">
                <img
                  src={contentBg}
                  alt="Scroll background"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 flex flex-col justify-center items-center">
                  <div className="w-[60%] text-center">
                    <p className="font-body text-sm md:text-base leading-relaxed mb-4 text-stone-800 font-semibold">
                      A 3rd-year Computer Science student at SRM AP University, I'm passionate about building intelligent, scalable solutions that blend full-stack development with machine learning.
                    </p>
                    <p className="font-body text-sm md:text-base leading-relaxed text-stone-800 font-semibold">
                      My expertise lies in crafting robust backends and intuitive frontends using technologies like Python, Flask, React, and SQL. I thrive on creative problem-solving and a commitment to excellence.
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <motion.div
                className="flex gap-4 justify-center md:justify-start"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.9, duration: 0.8 }}
              >
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant="default"
                    size="lg"
                    className="font-body gap-2 shadow-[var(--shadow-paper)] hover:shadow-[var(--shadow-lifted)] transition-all duration-500"
                  >
                    <FileText className="w-5 h-5" />
                    View Resume
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Background decoration */}
      <div className="absolute top-1/4 right-10 text-accent/5 pointer-events-none">
        <svg width="200" height="200" viewBox="0 0 200 200" fill="currentColor">
          <path d="M100 10 L40 190 L190 78 L10 78 L160 190 Z" />
        </svg>
      </div>
    </section>
  );
};
