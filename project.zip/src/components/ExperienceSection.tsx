import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { ExternalLink, Calendar, Github, Code2, Layers, Cloud, CloudRain, Zap, GraduationCap } from "lucide-react";

const education = [
  {
    period: "2023 – present",
    degree: "B.Tech CSE",
    institution: "SRM AP University",
    gpa: "GPA: 8.98/10",
  },
  {
    period: "2023",
    degree: "Class 12th",
    institution: "Bhashyam",
    gpa: "GPA: 9.73/10",
  },
];

const experiences = [
  {
    title: "Salesforce Developer Intern",
    company: "Smartbridge",
    period: "May 2025 - July 2025",
    description: "Worked on customizing Salesforce applications using Apex, Visualforce, and Lightning Web Components. Assisted in integrating third-party APIs, building automation with Flows and Process Builder, and deploying changes via Change Sets. Collaborated with cross-functional teams to gather requirements and deliver scalable CRM solutions.",
    tags: ["Salesforce", "Apex", "Visualforce", "Lightning", "Flows"],
  },
];

const projects = [
  {
    title: "ATS Resume Checker",
    description: "Developed a full-stack AI-powered platform using React, Flask, Python, spaCy, and Sentence Transformers for resume optimization. Implemented NLP-driven ATS analysis to provide detailed match scores, identify matching/missing skills, and offer actionable insights. Built an interactive ATS-friendly resume builder with live preview and PDF generation, streamlining professional resume creation.",
    link: "https://github.com/keerthi-1118/ats_resume_checker",
    tags: ["React", "Flask", "Python", "NLP", "spaCy"],
    thumbnail: "/images/ats.jpg", // User will add image later
  },
  {
    title: "Book Trading Platform",
    description: "Developed a polished web application enabling user authentication, book management, trade requests, and ratings. Built a React + Material UI frontend and a Flask + SQLAlchemy backend with JWT authentication. Packaged with Docker & docker-compose for seamless deployment and professional showcase.",
    link: "https://github.com/keerthi-1118",
    thumbnail: null, // User will add image later
    tags: ["React", "Flask", "JWT", "Docker", "Material UI"],
  },
  {
    title: "Cloud Buddy",
    description: "A lightweight weather app built with HTML, CSS, JS, and Bootstrap. It fetches real-time weather using WeatherAPI and uses Pexels API to display dynamic city backgrounds. Includes city search, current location weather, temperature, humidity, wind speed, a 3-day forecast, and smooth UI interactions.",
    link: "https://github.com/keerthi-1118/Live-weather-",
    tags: ["HTML", "CSS", "JavaScript", "Bootstrap", "WeatherAPI", "Pexels API"],
    thumbnail: "/images/cloudy.jpg",// User will add image later
    techIcons: [Cloud, CloudRain, Zap], // Weather-themed icons for tech hints
  },
];

export const ExperienceSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="experience" ref={ref} className="min-h-screen py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="max-w-6xl mx-auto"
        >
          <h2 className="font-heading text-5xl md:text-6xl mb-16 text-center ink-text">
            The Chronicle
          </h2>

          {/* Education and Experience Side-by-Side */}
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-20">
            {/* Education Timeline - LEFT SIDE */}
            <div>
              <h3 className="font-heading text-3xl mb-8 text-primary">Education</h3>
              <div className="space-y-8 relative before:absolute before:left-4 before:top-0 before:bottom-0 before:w-0.5 before:bg-accent/30">
                {education.map((edu, index) => (
                  <motion.div
                    key={`${edu.degree}-${index}`}
                    initial={{ opacity: 0, y: 20 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ delay: index * 0.2, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                    className="relative pl-12 group"
                    whileHover={{
                      scale: 1.02,
                      transition: { duration: 0.3, ease: "easeOut" }
                    }}
                  >
                    {/* Timeline dot */}
                    <div className="absolute top-0 left-4 w-4 h-4 bg-accent rounded-full border-4 border-background -translate-x-2 group-hover:scale-150 transition-all duration-500 z-10 group-hover:shadow-[0_0_20px_hsl(var(--accent)/0.6)]" />
                    
                    {/* Content indented to the right of timeline */}
                    <div className="relative">
                      {/* Golden glow on hover */}
                      <motion.div
                        className="absolute -inset-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                        style={{
                          background: 'radial-gradient(circle, hsl(var(--accent) / 0.2) 0%, transparent 70%)',
                          boxShadow: '0 0 30px hsl(var(--accent) / 0.4)',
                        }}
                      />
                      
                      <div className="relative flex items-center gap-2 mb-2">
                        <GraduationCap className="w-5 h-5 text-accent flex-shrink-0" />
                        <span className="font-body text-sm text-muted-foreground">{edu.period}</span>
                      </div>
                      
                      <h4 className="font-heading text-2xl mb-1">{edu.degree}</h4>
                      <p className="font-body text-lg text-accent mb-3">{edu.institution}</p>
                      <p className="font-body text-base text-muted-foreground">({edu.gpa})</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Professional Journey - RIGHT SIDE */}
            <div>
              <h3 className="font-heading text-3xl mb-8 text-primary">Professional Journey</h3>
              <div className="space-y-8 relative before:absolute before:left-4 before:top-0 before:bottom-0 before:w-0.5 before:bg-accent/30">
                {experiences.map((exp, index) => (
                  <motion.div
                    key={exp.title}
                    initial={{ opacity: 0, x: 25 }}
                    animate={isInView ? { opacity: 1, x: 0 } : {}}
                    transition={{ delay: index * 0.2, duration: 0.7, ease: "easeOut" }}
                    className="relative pr-12"
                  >
                    <div className="bg-card p-6 rounded-lg burnt-edge shadow-[var(--shadow-paper)] hover:shadow-[var(--shadow-lifted)] transition-all duration-500 group hover:scale-[1.02]">
                      {/* Timeline dot */}
                      <div className="absolute top-8 left-4 w-4 h-4 bg-accent rounded-full border-4 border-background -translate-x-2 group-hover:scale-150 transition-all duration-500" />
                      
                      <div className="flex items-start gap-2 mb-2">
                        <Calendar className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                        <span className="font-body text-sm text-muted-foreground">{exp.period}</span>
                      </div>
                      
                      <h4 className="font-heading text-2xl mb-1">{exp.title}</h4>
                      <p className="font-body text-lg text-accent mb-3">{exp.company}</p>
                      <p className="font-body text-base leading-relaxed mb-4">{exp.description}</p>
                      
                      <div className="flex flex-wrap gap-2">
                        {exp.tags.map(tag => (
                          <span
                            key={tag}
                            className="px-3 py-1 bg-accent/20 text-accent rounded-full text-sm font-body"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Featured Projects */}
          <div>
            <h3 className="font-heading text-3xl mb-8 text-primary">Notable Works</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
              {projects.map((project, index) => (
                <motion.div
                  key={project.title}
                  initial={{ opacity: 0, y: 25 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ 
                    delay: 0.3 + index * 0.1,
                    duration: 0.7,
                    ease: [0.22, 1, 0.36, 1]
                  }}
                  className="relative bg-card/80 backdrop-blur-sm rounded-3xl burnt-edge shadow-[var(--shadow-paper)] hover:shadow-[var(--shadow-lifted)] transition-all duration-700 group overflow-hidden border border-border/20 hover:border-accent/30 flex flex-col w-full max-w-[400px] h-full"
                  whileHover={{ y: -8, scale: 1.03, zIndex: 10, transition: { duration: 0.3, ease: "easeOut" } }}
                  style={{
                    minHeight: '600px',
                  }}
                >
                  {/* Thumbnail Area */}
                  <motion.div 
                    className="relative h-48 bg-gradient-to-br from-accent/10 via-primary/5 to-accent/10 overflow-hidden flex-shrink-0"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.5 }}
                    style={{
                      height: '192px',
                    }}
                  >
                    {/* Background image if provided */}
                    {project.thumbnail && (
                      <img 
                        src={project.thumbnail} 
                        alt={project.title}
                        className="absolute inset-0 w-full h-full object-cover opacity-80"
                      />
                    )}
                    
                    {/* Circuit lines pattern - subtle tech detail */}
                    <svg className="absolute inset-0 w-full h-full opacity-5" preserveAspectRatio="none">
                      <defs>
                        <pattern id={`circuit-${index}`} x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                          <path d="M0,20 L20,20 M20,20 L20,0 M20,20 L40,20" stroke="hsl(var(--accent))" strokeWidth="0.5" fill="none" />
                          <circle cx="20" cy="20" r="2" fill="hsl(var(--accent))" opacity="0.3" />
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill={`url(#circuit-${index})`} />
                    </svg>

                    {/* Binary texture - subtle tech detail */}
                    <div className="absolute inset-0 opacity-[0.02] font-mono text-xs text-accent" style={{ 
                      backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 10px, hsl(var(--accent)) 10px, hsl(var(--accent)) 11px), repeating-linear-gradient(90deg, transparent, transparent 10px, hsl(var(--accent)) 10px, hsl(var(--accent)) 11px)',
                    }} />
                    
                    {/* Subtle tech pattern overlay */}
                    <div className="absolute inset-0 opacity-10">
                      {project.techIcons ? (
                        // Custom icons for specific projects (like Cloud Buddy)
                        <>
                          <div className="absolute top-4 left-4">
                            {project.techIcons[0] && (() => {
                              const IconComponent = project.techIcons[0];
                              return <IconComponent className="w-12 h-12 text-accent rotate-12" />;
                            })()}
                          </div>
                          <div className="absolute bottom-4 right-4">
                            {project.techIcons[1] && (() => {
                              const IconComponent = project.techIcons[1];
                              return <IconComponent className="w-10 h-10 text-accent -rotate-12" />;
                            })()}
                          </div>
                          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                            {project.techIcons[2] && (() => {
                              const IconComponent = project.techIcons[2];
                              return <IconComponent className="w-8 h-8 text-accent rotate-45" />;
                            })()}
                          </div>
                        </>
                      ) : (
                        // Default tech icons
                        <>
                          <div className="absolute top-4 left-4">
                            <Code2 className="w-12 h-12 text-accent rotate-12" />
                          </div>
                          <div className="absolute bottom-4 right-4">
                            <Layers className="w-10 h-10 text-accent -rotate-12" />
                          </div>
                          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                            <div className="w-20 h-20 border-2 border-accent/20 rounded-lg rotate-45" />
                          </div>
                        </>
                      )}
                    </div>

                    {/* Corner decoration */}
                    <div className="absolute top-2 right-2 w-16 h-16 border-t-2 border-r-2 border-accent/20 rounded-tr-lg opacity-50" />
                    <div className="absolute bottom-2 left-2 w-12 h-12 border-b-2 border-l-2 border-accent/20 rounded-bl-lg opacity-50" />
                  </motion.div>

                  {/* Content Area */}
                  <div className="p-6 flex flex-col flex-1">
                    <motion.h4 
                      className="font-heading text-2xl mb-3 group-hover:text-accent transition-colors duration-500"
                      whileHover={{ x: 4 }}
                    >
                      {project.title}
                    </motion.h4>
                    
                    <p className="font-body text-base leading-relaxed mb-6 text-muted-foreground flex-grow" 
                       style={{
                         fontSize: '1rem',
                         lineHeight: '1.625rem',
                         minHeight: '4.875rem',
                       }}>
                      {project.description}
                    </p>

                    {/* Tech Tags */}
                    <div className="flex flex-wrap gap-2 mb-6">
                      {project.tags.map((tag, tagIndex) => (
                        <motion.span
                          key={tag}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={isInView ? { opacity: 1, scale: 1 } : {}}
                          transition={{ 
                            delay: 0.5 + index * 0.1 + tagIndex * 0.05,
                            duration: 0.4
                          }}
                          className="px-3 py-1.5 bg-accent/15 text-accent rounded-full text-sm font-body border border-accent/20 hover:bg-accent/25 transition-all duration-300"
                          whileHover={{ scale: 1.05 }}
                        >
                          {tag}
                        </motion.span>
                      ))}
                    </div>

                    {/* Gold-stamped/Wax-seal View on GitHub Button */}
                    <motion.a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group/btn relative inline-flex items-center justify-center gap-2 w-full px-6 py-4 rounded-full font-body text-base font-semibold transition-all duration-700 overflow-hidden mt-auto"
                      style={{
                        background: 'linear-gradient(135deg, hsl(45, 100%, 60%) 0%, hsl(38, 92%, 50%) 50%, hsl(45, 100%, 55%) 100%)',
                        border: '2px solid hsl(45, 100%, 45%)',
                        boxShadow: `
                          inset 0 2px 4px rgba(255, 255, 255, 0.3),
                          inset 0 -2px 4px rgba(0, 0, 0, 0.2),
                          0 4px 12px hsl(45, 100%, 40% / 0.4),
                          0 2px 4px rgba(0, 0, 0, 0.2)
                        `,
                        color: 'hsl(30, 80%, 15%)',
                        textShadow: '0 1px 2px rgba(255, 255, 255, 0.5)',
                      }}
                      whileHover={{
                        scale: 1.05,
                        y: -2,
                        boxShadow: `
                          inset 0 2px 6px rgba(255, 255, 255, 0.4),
                          inset 0 -2px 6px rgba(0, 0, 0, 0.3),
                          0 8px 24px hsl(45, 100%, 40% / 0.6),
                          0 4px 8px rgba(0, 0, 0, 0.3),
                          0 0 20px hsl(45, 100%, 50% / 0.5)
                        `,
                        borderColor: 'hsl(45, 100%, 50%)',
                      }}
                      whileTap={{ scale: 0.98, y: 0 }}
                    >
                      {/* Wax seal shimmer effect */}
                      <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                        initial={{ x: '-200%', rotate: -45 }}
                        whileHover={{ x: '200%' }}
                        transition={{ duration: 1, repeat: Infinity, repeatDelay: 2 }}
                      />
                      
                      {/* Inner glow */}
                      <motion.div
                        className="absolute inset-1 rounded-full bg-gradient-to-br from-white/20 to-transparent"
                        initial={{ opacity: 0.5 }}
                        whileHover={{ opacity: 1 }}
                        transition={{ duration: 0.3 }}
                      />
                      
                      <Github className="w-5 h-5 relative z-10 transition-all duration-500 group-hover/btn:rotate-12 group-hover/btn:scale-110 drop-shadow-sm" />
                      <span className="relative z-10 transition-all duration-500 drop-shadow-sm">
                        View on GitHub
                      </span>
                      <motion.div
                        className="relative z-10"
                        initial={{ x: 0 }}
                        whileHover={{ x: 4 }}
                        transition={{ duration: 0.3 }}
                      >
                        <ExternalLink className="w-4 h-4 drop-shadow-sm" />
                      </motion.div>
                    </motion.a>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
